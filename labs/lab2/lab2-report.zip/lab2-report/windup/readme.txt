Overview:
=========
  This is a very basic example that demonstrates how to configure the FTP
  gateway, Camel gateway, and JMS router.
  
